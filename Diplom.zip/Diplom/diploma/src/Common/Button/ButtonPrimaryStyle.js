import { css } from "@emotion/css";
import { Button } from "@mui/material"

// const buttonStyle = `
//     color: #fff;
//     box-shadow: none;
//     text-transform: none;
//     font-size: 16;
//     padding: 12px 24px;
//     border: 1px solid #0063cc;
//     border-radius: 24px;
//     line-height: 1.5;
//     background-color: #0063cc;
//     font-family: "Roboto";

// &:hover {
//     background-color: #52a4fa;
//     border-color: #fff;
//     box-shadow: none;
// }

// &:active {
//     box-shadow: none;
//     background-color: #0062cc;
//     border-color: #005cbf;
// }

// &:focus {
//     box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, .5);
// }
// `;

export const buttonStyle = {
    color: "#fff",
    boxShadow: "none",
    textTransform: "none",
    fontSize: 16,
    padding: "12px 24px",
    border: "1px solid #0063cc",
    borderRadius: "24px",
    lineHeight: 1.5,
    backgroundColor: "#0063cc",
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:hover": {
      backgroundColor: "#52a4fa",
      borderColor: "#fff",
      boxShadow: "none",
    },
    "&:active": {
      boxShadow: "none",
      backgroundColor: "#0062cc",
      borderColor: "#005cbf",
    },
    "&:focus": {
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.5)",
    },
  };

export default buttonStyle;