import { Button, Container, Divider, Typography } from "@mui/material";
import buttonStyle from '../../Common/Button/ButtonPrimaryStyle';
import { NavLink } from "react-router-dom";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';

import shipDownWhite from '../../assets/images/ship-down-white.png'
import Canvas from "../../Common/Canvas/Canvas";
import { GlobalContext } from "../../App";
import { useContext } from "react";
import { Gauge, gaugeClasses } from '@mui/x-charts/Gauge';

const mainMenuWrapperStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    height: '100%',
    padding: '12px 0 0'
};

const mainHeaderStyle = {
    // flex: 1,
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    
};

const canvasWrapperStyle = {
    // flex: 2,
    display: 'flex',
    flexDirection: 'column',
    justifyContent:  'center',
    alignItems:  'center',
};

const utilsWrapperStyle = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '8px',
    margin: '48px 0'
};

const utilsLeftStyle = {
    flex: 1,
    fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol"',
    margin: '4px',
};

const utilsRightStyle = {
    flex: 1,
    display: 'grid',
    gridTemplateColumns: '1fr 1fr 1fr ',
    gridTemplateRows: '1fr 1fr 1fr ',
    // gap: '8px',
};

const chartItem = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    border: '1px solid #fff',
    borderRadius: '24px',
    margin: '4px',
}

const utilsLeftInnerStyle = {
    border: '1px solid #fff',
    borderRadius: '24px',
    padding: '24px',
}

const listItemStyle = {
    display: 'grid',
    textAlign: 'left',
    gridTemplateColumns: '4fr 1fr',
    margin: '0 0 4px',
}

const scenariosWrapper = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'stretch',
    justifyContent: 'start',
}

const scenarioItem = {
    display: 'grid',
    textAlign: 'left',
    gridTemplateColumns: '3fr 3fr 1fr',
    alignItems: 'center',
    columnGap: '4px',

    width: '100%',
    border: '1px solid #fff',
    borderRadius: '24px',
    padding: '8px 12px',
    margin: '9px 0',
}



const footerStyle = {
    padding: '24px'
}

export const Main = () => {
    const { width: viewportWidth, height: viewportHeight} = useContext(GlobalContext);
    return (<>
        <NavLink to={'/'}> 
            <Button 
                sx={{
                    ...buttonStyle, 
                    position: 'absolute',
                    top: '12px',
                    left: '12px',
                    minWidth: 0, 
                    padding: '12px',

                }} 
                variant="contained"
            >
                <ArrowBackIcon />
            </Button>
        </NavLink>
        <Container sx={mainMenuWrapperStyle}>
                <div className="mainHeader" style={mainHeaderStyle}>
                    <h4 style={{minHeight: '50px',}}>
                        Разработка имитатора технических средств судна
                    </h4>
                </div>

                <div className="canvasWrapper" style={canvasWrapperStyle}>
                    {/* <img src={shipDownWhite} alt='ship'/> */}
                    <Canvas canvasHeight={viewportHeight/2} canvasWidth={viewportWidth*0.9} imagePath={shipDownWhite} />
                </div>

                <div className="utilsWrapper" style={utilsWrapperStyle}>
                    <div className="utilsLeft" style={utilsLeftStyle}>
                        <div className="utilsLeftInner" style={utilsLeftInnerStyle}>
                            <Typography component='h3' variant="subtitle2" sx={{fontSize: '18px', textAlign: 'center'}}>
                                Дополнительная информация о судне
                            </Typography>
                            <Divider orientation="horizontal" sx={{
                                borderColor: 'rgba(255,255,255,012)',
                                marginBottom: '12px',
                                paddingBottom: '12px'
                                }}/>
                            <ul>
                                <li style={listItemStyle}>
                                    <span>Длина габаритная с отбойным устройством</span> 
                                    <span>27,35 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Длина наибольшая</span> 
                                    <span>26,81 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Ширина габаритная с отбойным устройством </span>
                                    <span>10,12 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Ширина наибольшая </span>
                                    <span>9,50 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Высота борта на миделе </span>
                                    <span>3,3 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Осадка по КВЛ </span>
                                    <span>2,35 м</span></li>
                                <li style={listItemStyle}>
                                    <span>Водоизмещение при осадке по КВЛ (соленая вода) </span>
                                    <span>380 T</span></li>
                                <li style={listItemStyle}>
                                    <span>Главный двигатели </span>
                                    <span>ок. 2х634 кВт</span></li>
                                <li style={listItemStyle}>
                                    <span>Тяга на гаке </span>
                                    <span>20 тс</span></li>
                                <li style={listItemStyle}>
                                    <span>Класс Российского Морского Регистра</span> 
                                    <span>КМ® Ice3 R2 AUT3 FF3WS Tug</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="utilsRight" style={utilsRightStyle}>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 1
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={60} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 2
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={37} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 3
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={9} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 4
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={72} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 5
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={36} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 6
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={89} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 7
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={23} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 8
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={15} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                        <div style={chartItem}>
                            <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                Датчик 9
                            </Typography>
                            <Gauge 
                                width={100} 
                                height={100} 
                                value={47} 
                                startAngle={-90} 
                                endAngle={90} 
                                sx={(theme) => ({
                                    [`& .${gaugeClasses.valueText} text`]: {
                                    fontSize: 20,
                                    fill: '#fff'
                                    },
                                    [`& .${gaugeClasses.referenceArc}`]: {
                                    fill: theme.palette.text.disabled,
                                    },
                                })}
                            />
                        </div>
                    </div>

                </div>
                
                <div style={scenariosWrapper}>
                    <div style={scenarioItem}>
                        <div style={{textAlign: 'start'}}>
                        <Typography component='p' variant="subtitle3" sx={{fontSize: '20px'}}>
                            Сценарий 1
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '4px', fontSize: '16px'}}>
                            В данном сценарии происходит имитация поломок следующих отсеков:
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '8px', fontSize: '16px'}}>
                            Отсек 3, Отсек 4,  Отсек 8, Капитанский мостик
                        </Typography>
                        </div>

                        <div style={{display: 'flex'}}>
                                <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 1
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 4
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 7
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 8
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div><div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 9
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                        </div>
                        
                        <div 
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}
                        >
                            <Button 
                                sx={{
                                    ...buttonStyle, 
                                    minWidth: 0, 
                                    padding: '12px',

                                }} 
                                variant="contained"
                            >
                                <PlayArrowIcon />
                            </Button>
                        </div>
                    </div>

                    <div style={scenarioItem}>
                        <div style={{textAlign: 'start'}}>
                        <Typography component='p' variant="subtitle3" sx={{fontSize: '20px'}}>
                            Сценарий 2
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '4px', fontSize: '16px'}}>
                            В данном сценарии происходит имитация поломок следующих отсеков:
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '8px', fontSize: '16px'}}>
                            Отсек 1, Отсек 2,  Отсек 3, Отсек 9
                        </Typography>
                        </div>

                        <div style={{display: 'flex'}}>
                                <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 1
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 4
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 7
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 8
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div><div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 9
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                        </div>
                        
                        <div 
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}
                        >
                            <Button 
                                sx={{
                                    ...buttonStyle, 
                                    minWidth: 0, 
                                    padding: '12px',

                                }} 
                                variant="contained"
                            >
                                <PlayArrowIcon />
                            </Button>
                        </div>
                    </div>

                    <div style={scenarioItem}>
                        <div style={{textAlign: 'start'}}>
                        <Typography component='p' variant="subtitle3" sx={{fontSize: '20px'}}>
                            Сценарий 3
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '4px', fontSize: '16px'}}>
                            В данном сценарии происходит имитация поломок следующих отсеков:
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '8px', fontSize: '16px'}}>
                            Отсек 4, Отсек 5,  Отсек 6
                        </Typography>
                        </div>

                        <div style={{display: 'flex'}}>
                                <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 1
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 4
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 7
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 8
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div><div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 9
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                        </div>
                        
                        <div 
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}
                        >
                            <Button 
                                sx={{
                                    ...buttonStyle, 
                                    minWidth: 0, 
                                    padding: '12px',

                                }} 
                                variant="contained"
                            >
                                <PlayArrowIcon />
                            </Button>
                        </div>
                    </div>

                    <div style={scenarioItem}>
                        <div style={{textAlign: 'start'}}>
                        <Typography component='p' variant="subtitle3" sx={{fontSize: '20px'}}>
                            Сценарий 4
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '4px', fontSize: '16px'}}>
                            В данном сценарии происходит имитация поломок следующих отсеков:
                        </Typography>
                        <Typography component='p' variant="subtitle3" sx={{marginTop: '8px', fontSize: '16px'}}>
                            Отсек 3, Отсек 5, Отсек 6
                        </Typography>
                        </div>

                        <div style={{display: 'flex'}}>
                                <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 1
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 4
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div> 
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 7
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={100} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                            <div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 8
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div><div style={chartItem}>
                                    <Typography component='p' variant="subtitle3" sx={{fontSize: '16px'}}>
                                        Датчик 9
                                    </Typography>
                                    <Gauge 
                                        width={100} 
                                        height={100} 
                                        value={0} 
                                        startAngle={-90} 
                                        endAngle={90} 
                                        sx={(theme) => ({
                                            [`& .${gaugeClasses.valueText} text`]: {
                                            fontSize: 20,
                                            fill: '#fff'
                                            },
                                            [`& .${gaugeClasses.referenceArc}`]: {
                                            fill: theme.palette.text.disabled,
                                            },
                                        })}
                                    /> 
                            </div>
                        </div>
                        
                        <div 
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}
                        >
                            <Button 
                                sx={{
                                    ...buttonStyle, 
                                    minWidth: 0, 
                                    padding: '12px',

                                }} 
                                variant="contained"
                            >
                                <PlayArrowIcon />
                            </Button>
                        </div>
                    </div>
                </div>

                <div style={footerStyle}>

                </div>
        </Container>        
    </>
        
    );
};
