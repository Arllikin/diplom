import { Button, Container } from "@mui/material";
import { NavLink } from "react-router-dom";
import buttonStyle from '../../Common/Button/ButtonPrimaryStyle';

const mainMenuWrapperStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    height: '100%',
}

const mainHeaderStyle = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
}

const mainListStyle = {
    flex: 2,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
}

export const MainMenu = () => {
    return (
      <Container sx={mainMenuWrapperStyle}>
        <div className="mainHeader" style={mainHeaderStyle}>
            <h1>
                Разработка имитатора технических средств судна
            </h1>
            <h3>
                Поворов И.А
            </h3>
        </div>
        <div className="mainList" style={mainListStyle}>
            <NavLink to={'/main'}> <Button sx={{...buttonStyle}} variant="contained">Начать</Button></NavLink>
        </div>
      </Container>
      );
  };
  