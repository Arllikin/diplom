import './App.css';
import './Common/Button/Button.css';


// import { css } from '@emotion/css'

import { createContext, useContext, useEffect, useMemo, useRef } from 'react';
import AppThemeProvider from "./themes/AppThemeProvider";
import { HashRouter, Routes, Route, NavLink } from 'react-router-dom';
import { Container, css } from '@mui/material';
import Button from '@mui/material/Button';
import buttonStyle from './Common/Button/ButtonPrimaryStyle';
import { MainMenu } from './pages/MainMenu/MainMenu';
import { Main } from './pages/Main/Main';
import useWindowDimensions from './hooks/useWindowDimensions';

export const GlobalContext = createContext(null);

function App() {
  const { height, width } = useWindowDimensions();
  const theme = 'dark';


  return (
    <div className="App">
      {/* <header className="App-header">

      </header> */}
      <main>
      <GlobalContext.Provider value={{
        height,
        width,
        theme,
      }}>
        <AppThemeProvider>
          <HashRouter>
            <Routes>
              <Route path='/' element={<MainMenu />}></Route>
              <Route path='/main' element={<Main />}></Route>
            </Routes>
          </HashRouter>
        </AppThemeProvider>
      </GlobalContext.Provider>
      </main>
    </div>
  );
}

export default App;
